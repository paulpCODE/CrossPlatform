﻿using System.Collections.Generic;
using System.IO;

namespace LabLib;

public class FileManager
{
    private static int counter = 0;
    
    private SortedDictionary<int, string> savedFiles;
    
    public SortedDictionary<int, string> SavedFiles { get { return savedFiles; } }
    public FileManager()
    {
        savedFiles = new SortedDictionary<int, string>();
    }
    
    public bool IsHandleValidInThisManager(FileHandle handle)
    {
        if(handle == null)
        {
            return false;
        }
        if(!handle.IsValid())
        {
            return false;
        }
        if(savedFiles.ContainsKey(handle.Index))
        {
            return true;
        }
        return false;
    }
    
    public FileHandle AddFile(string path)
    {
        if(File.Exists(Path.GetFullPath(path)))
        {
            savedFiles.Add(counter, Path.GetFullPath(path));
            return new FileHandle(counter++);
        }
        return new FileHandle();
    }
    
    public bool RemoveFile(FileHandle handle)
    {
        if(IsHandleValidInThisManager(handle))
        {
            savedFiles.Remove(handle.Index);
            return true;
        }
        return false;
    }
    
    public StreamReader? CreateReader(FileHandle handle)
    {
        if(IsHandleValidInThisManager(handle))
        {
            return File.OpenText(savedFiles[handle.Index]); 
        }
        return null;
    }
    
    public StreamWriter? CreateWriter(FileHandle handle)
    {
        if (IsHandleValidInThisManager(handle))
        {
            return File.CreateText(savedFiles[handle.Index]);
        }
        return null;
    }
}