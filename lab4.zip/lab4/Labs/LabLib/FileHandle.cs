﻿namespace LabLib;

public class FileHandle
{
    private static int INVALID_INDEX = -1;
    
    private int index;
    
    public int Index { get { return index; } }
    public FileHandle()
    {
        index = INVALID_INDEX;
    }
    
    public FileHandle(int index)
    {
        this.index = index;
    }
    
    public bool IsValid()
    {
        return index != INVALID_INDEX;
    }
}