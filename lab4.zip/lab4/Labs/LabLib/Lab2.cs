﻿using System;
using System.Collections.Generic;
using System.IO;

namespace LabLib;

public class Platforms
{ 
    public List<int> Heights { get; set; }

    public Platforms()
    {
        Heights = new List<int>();
    }

    public int DistanceBetweenPlatforms(int index1, int index2)
    {
        if(Heights.Count > index1 && Heights.Count > index2 && index1 >= 0 && index2 >= 0)
        {
            return Math.Abs(Heights[index2] - Heights[index1]);
        }
        return -1;
    }

    public int SuperSkillBetween(int index1, int index2)
    {
        if (Heights.Count > index1 && Heights.Count > index2 && index1 >= 0 && index2 >= 0)
        {
            return 3 * Math.Abs(Heights[index2] - Heights[index1]);
        }
        return -1;
    }

    /*public int FindMinimalRecursive(int index)
    {
        int sum = 0;
        int minimal = 0;
        if (index + 2 < Heights.Count)
        {
            minimal = DistanceBetweenPlatforms(index, index + 1);
            if (DistanceBetweenPlatforms(index, index + 1) + DistanceBetweenPlatforms(index + 1, index + 2) > SuperSkillBetween(index, index+2))
            {
                int v1min = FindMinimalRecursive(index + 1);
                int v2min = FindMinimalRecursive(index + 2);
                sum += v1min > v2min ? v1min : v2min;
            }
            else
            {
                sum += FindMinimalRecursive(index + 1);
            }
        }
        else if(index + 1 < Heights.Count)
        {
            return DistanceBetweenPlatforms(index, index + 1);
        }
        else
        {
            return 0;
        }
        
    }*/

    public int CalculateMinimalValue()
    {
        int sumOfPoints = 0;
        int minimal = 0;
        for(int i = 0; i < Heights.Count - 1; i++)
        {
            if(i + 2 < Heights.Count)
            {
                minimal = DistanceBetweenPlatforms(i, i + 1) + DistanceBetweenPlatforms(i + 1, i + 2);
                if(minimal > SuperSkillBetween(i, i+2))
                {
                    minimal = SuperSkillBetween(i, i+2);
                }
                sumOfPoints += minimal;
                i++;
            }
            else if(i + 1 < Heights.Count)
            {
                sumOfPoints += DistanceBetweenPlatforms(i, i + 1);
            }
        }

        return sumOfPoints;
    }
}


public class Lab2
{
    public static void Run(string input, string output)
    {
        string path = new string("../../../");
        string inputFileName = new string("input2.txt");
        string outputFileName = new string("output2.txt");
        string delimeter = new string(" ");

        Platforms platforms = new Platforms();

        FileManager fileManager = new FileManager();
        FileHandle inputHandle = fileManager.AddFile(input);
        FileHandle outputHandle = fileManager.AddFile(output);
        if(!inputHandle.IsValid() || !outputHandle.IsValid())
        {
            Console.WriteLine("One of handles are not valid!");
            return;
        }

        StreamReader? sr = fileManager.CreateReader(inputHandle);
        StreamWriter? writer = fileManager.CreateWriter(outputHandle);
        if(sr == null || writer == null)
        {
            Console.WriteLine("Cant create reader for " + inputFileName + " or writer for " + outputFileName);
            return;
        }

        int numberOfPlatforms = 0;
        if(!Int32.TryParse(sr.ReadLine(), out numberOfPlatforms))
        {
            Console.WriteLine("Cant parse first line of input file to int");
            return;
        }
        if(numberOfPlatforms < 0)
        {
            Console.WriteLine("numberOfPlatforms cant be a negative number");
            return;
        }
        string? dataPlatforms = sr.ReadLine();
        if(dataPlatforms == null)
        {
            Console.WriteLine("Second line of input is null");
            return;
        }
        string[] words = dataPlatforms.Split(delimeter);
        foreach(string word in words)
        {
            if(Int32.TryParse(word, out int height)) {
                platforms.Heights.Add(height);
            } 
            else
            {
                Console.WriteLine("Cant convert data from second line to ints with delimeter: " + delimeter);
                return;
            }
        }

        writer.WriteLine(platforms.CalculateMinimalValue());
        Console.WriteLine("Success!");

        sr.Close();
        writer.Close();
    }
};
