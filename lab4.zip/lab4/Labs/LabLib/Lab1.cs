﻿using System;
using System.Collections.Generic;
using System.IO;

namespace LabLib;
class SectionValue
{
    private int _value;
    private string _name;

    public int Get => _value;
    public string GetName => _name;
    
    public SectionValue(int value)
    {
        _value = value;
        _name = value.ToString();
    }

    public SectionValue(int value, string name)
    {
        _value = value;
        _name = name;
    }

    public override string ToString()
    {
        return _name;
    }
}

class WinCombination
{
    private List<SectionValue> _winCombination;

    public WinCombination(List<SectionValue> winComb)
    {
        _winCombination = new List<SectionValue>(winComb);
    }
    public override string ToString()
    {
        string winComb = new string("");
        foreach(SectionValue value in _winCombination)
        {
            winComb = winComb + value.ToString() + " ";
        }
        return winComb;
    }
}

class Darts
{
    List<SectionValue> _sectionValues;

    bool isAll;

    public Darts()
    {
        _sectionValues = new List<SectionValue>();

        for (int i = 1; i <= 20; i++)
        {
            _sectionValues.Add(new SectionValue(i));
            _sectionValues.Add(new SectionValue(i * 2, "D" + i.ToString()));
            _sectionValues.Add(new SectionValue(i * 3, "T" + i.ToString()));
        }

        _sectionValues.Add(new SectionValue(25));
        _sectionValues.Add(new SectionValue(50, "Bull"));
        isAll = false;
    }

    public List<WinCombination> FindWinCombinationsCount(int targetCount, int targetPoints)
    {
        List<WinCombination> result = new List<WinCombination>();
        List<SectionValue> partial = new List<SectionValue>();

        for (int i = 0; i < _sectionValues.Count; i++)
        {
            if (isAll) { break; }
            partial.Add(_sectionValues[i]);
            checkForWin(targetPoints, targetCount, ref partial, ref result);
            if (isAll) { break; }
            partial.Add(_sectionValues[i]);
            checkForWin(targetPoints, targetCount, ref partial, ref result);
            if (isAll) { break; }
            partial.Add(_sectionValues[i]);
            checkForWin(targetPoints, targetCount, ref partial, ref result);
            partial.Clear();

            for (int j = i + 1; j < _sectionValues.Count; j++)
            {
                if (isAll) { break; }
                partial.Add(_sectionValues[i]);
                partial.Add(_sectionValues[j]);
                checkForWin(targetPoints, targetCount, ref partial, ref result);
                if (isAll) { break; }
                partial.Add(_sectionValues[i]);
                checkForWin(targetPoints, targetCount, ref partial, ref result);
                if (isAll) { break; }
                partial[partial.Count - 1] = _sectionValues[j];
                checkForWin(targetPoints, targetCount, ref partial, ref result);
                partial.Clear();

                for (int k = j + 1; k < _sectionValues.Count; k++)
                {
                    if (isAll) { break; }
                    partial.Add(_sectionValues[i]);
                    partial.Add(_sectionValues[j]);
                    partial.Add(_sectionValues[k]);
                    checkForWin(targetPoints, targetCount, ref partial, ref result);
                    partial.Clear();
                }
            }
        }

        if (targetCount == result.Count)
        {
            Console.WriteLine("All elements found");

        }
        else if (targetCount > result.Count)
        {
            Console.WriteLine("Found count: " + result.Count);
        }

        isAll = false;
        return result;
    }

    private void checkForWin(int targetSum, int targetCount, ref List<SectionValue> partial, ref List<WinCombination> result)
    {
        int Sum = partial[0].Get;
        if (partial.Count > 1)
        {
            for(int i = 1; i < partial.Count; i++)
            {
                Sum += partial[i].Get;
            }
        }
        if(Sum == targetSum)
        {
            result.Add(new WinCombination(partial));
            if (targetCount == result.Count)
            {
                isAll = true;
            }
        }
    }
}

public class Lab1
{
    public static void Run(string input, string output)
    {
        string path = new string("../../../");
        string inputFileName = new string("input1.txt");
        string outputFileName = new string("output1.txt");

        FileManager fileManager = new FileManager();
        FileHandle inputHandle = fileManager.AddFile(input);
        FileHandle outputHandle = fileManager.AddFile(output);
        if (!inputHandle.IsValid() || !outputHandle.IsValid())
        {
            Console.WriteLine("One of handles are not valid!");
            return;
        }

        StreamReader? sr = fileManager.CreateReader(inputHandle);
        StreamWriter? writer = fileManager.CreateWriter(outputHandle);
        if (sr == null || writer == null)
        {
            Console.WriteLine("Cant create reader for " + inputFileName + " or writer for " + outputFileName);
            return;
        }

        int remainingPoints = 0;
        if (!Int32.TryParse(sr.ReadLine(), out remainingPoints))
        {
            Console.WriteLine("Cant parse first line of input file to int");
            return;
        }

        int countOfWinCombinationsToFound = 0;
        if (!Int32.TryParse(sr.ReadLine(), out countOfWinCombinationsToFound))
        {
            Console.WriteLine("Cant parse second line of input file to int");
            return;
        }

        Darts darts = new Darts();

        List<WinCombination> FoundCombinations = new List<WinCombination>();
        FoundCombinations = darts.FindWinCombinationsCount(countOfWinCombinationsToFound, remainingPoints);

        foreach(WinCombination comb in FoundCombinations)
        {
            Console.WriteLine(comb.ToString());
            writer.WriteLine(comb.ToString());
        }

        sr.Close();
        writer.Close();
        
    }
}

